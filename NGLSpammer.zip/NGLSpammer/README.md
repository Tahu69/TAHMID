# NGL Spammer
NGL Spammer is a Node.js-based tool designed to automate the process of sending multiple anonymous messages to a target user. This software is capable of bypassing NGL's block-sender mechanism.

## Prerequisites

- [Node.js](https://nodejs.org)
- [npm](https://npmjs.com) or [yarn](https://yarnpkg.com)

> [!WARNING]
> **Misuse of this tool for illegal activities, harassment, or malicious purposes is strictly prohibited and could lead to serious consequences.**
> **Always obtain proper permissions and comply with all applicable laws before using tools like this.**

## Installation
```bash
git clone https://github.com/Kairu-bit/NGLSpammer &&
cd NGLSpammer &&
npm install &&
npm start
```
